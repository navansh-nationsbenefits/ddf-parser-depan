package com.pwc.mastercard_ddf_service.config;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.FIELD_MAPPING_FILE;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.FIELD_MAPPING_FILE_NOT_FOUND;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.LOADED_FIELD_MAPPING;
import com.pwc.mastercard_ddf_service.domain.FieldMapping;
import jakarta.annotation.PostConstruct;
import lombok.Getter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * The type Field mapping config.
 */
@Component
public class FieldMappingConfig {
    private static final Logger log = LoggerFactory.getLogger(FieldMappingConfig.class);

    private final ObjectMapper objectMapper;
    @Getter
    private List<FieldMapping> fieldMappings;

    @Autowired
    public FieldMappingConfig(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    /**
     * Load field mappings.
     *
     * @exception IOException the io exception
     */
    @PostConstruct
    private void loadFieldMappings() throws IOException {
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream(FIELD_MAPPING_FILE);

        if (inputStream == null) {
            throw new FileNotFoundException(FIELD_MAPPING_FILE_NOT_FOUND);
        }

        TypeReference<List<FieldMapping>> typeRef = new TypeReference<>() {};
        this.fieldMappings = objectMapper.readValue(inputStream, typeRef);

        log.info(LOADED_FIELD_MAPPING, fieldMappings.size());
    }

}
