package com.pwc.mastercard_ddf_service.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration class that binds properties prefixed with "batch" from the application
 * configuration file to this class.
 *
 * <p>This is typically used to externalize configuration related to batch processing, such as
 * transaction limits.</p>
 */
@Configuration
@ConfigurationProperties(prefix = "batch")
@Getter
@Setter
public class BatchConfig {

    /**
     * The maximum number of transactions to be processed in a single batch.
     */
    private int transaction;

}