package com.pwc.mastercard_ddf_service.config;

import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration class for setting up Azure Blob Storage clients.
 *
 * <p>This class defines beans for connecting to Azure Blob Storage containers by reading
 * connection strings and container names from the application's configuration properties.</p>
 *
 * <p>It provides two {@link BlobContainerClient} beans:
 * <ul>
 *     <li>A client for the main storage container</li>
 *     <li>A client for the enriched data storage container</li>
 * </ul>
 * </p>
 */
@Configuration
public class ClientConfig {

    @Value("${azure.storage.connection-string}")
    private String connectionString;

    @Value("${azure.storage.container-name}")
    private String containerName;

    @Value("${azure.enriched.storage.connection-string}")
    private String enrichedConnectionString;

    @Value("${azure.enriched.storage.container-name}")
    private String enrichedContainerName;

    /**
     * Creates a {@link BlobContainerClient} for the main Azure Blob Storage container.
     *
     * @return the {@link BlobContainerClient} connected to the configured container
     */
    @Bean
    public BlobContainerClient blobContainerClient() {

        return new BlobServiceClientBuilder().connectionString(connectionString).buildClient()
                .getBlobContainerClient(containerName);
    }

    /**
     * Creates a {@link BlobContainerClient} for the enriched data Azure Blob Storage container.
     *
     * @return the {@link BlobContainerClient} connected to the configured enriched container
     */
    @Bean
    public BlobContainerClient enrichedBlobContainerClient() {

        return new BlobServiceClientBuilder().connectionString(enrichedConnectionString).buildClient()
                .getBlobContainerClient(enrichedContainerName);
    }
}
