package com.pwc.mastercard_ddf_service.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception thrown when an error occurs during file processing. This could be caused by issues such as file I/O errors,
 * missing files, or file format issues.
 */
@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
public class StorageUploadException extends RuntimeException {

    /**
     * Default constructor. Initializes a new instance of the exception with no message or cause.
     */
    public StorageUploadException() {

        super();
    }

    /**
     * Constructor with a message. Initializes a new instance of the exception with the provided message.
     *
     * @param message The detail message for the exception.
     */
    public StorageUploadException(String message) {

        super(message);
    }

    /**
     * Constructor with a message and cause. Initializes a new instance of the exception with the provided message and
     * cause.
     *
     * @param message The detail message for the exception.
     * @param cause The cause of the exception (can be retrieved later).
     */
    public StorageUploadException(String message, Throwable cause) {

        super(message, cause);
    }

    /**
     * Constructor with a cause. Initializes a new instance of the exception with the provided cause.
     *
     * @param cause The cause of the exception (can be retrieved later).
     */
    public StorageUploadException(Throwable cause) {

        super(cause);
    }

    /**
     * Constructor with a message, cause, and additional options. Initializes a new instance of the exception with the
     * provided message, cause, suppression enabled, and stack trace writable.
     *
     * @param message The detail message for the exception.
     * @param cause The cause of the exception (can be retrieved later).
     * @param enableSuppression Whether suppression is enabled for the exception.
     * @param writableStackTrace Whether the stack trace should be writable.
     */
    public StorageUploadException(String message, Throwable cause, boolean enableSuppression,
                                  boolean writableStackTrace) {

        super(message, cause, enableSuppression, writableStackTrace);
    }
}
