package com.pwc.mastercard_ddf_service.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception thrown when an error occurs during transaction processing. This can occur due to issues like timeouts, task
 * interruptions, or other internal processing failures.
 */
@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
public class TransactionProcessingException extends RuntimeException {

    /**
     * Default constructor. Initializes a new instance of the exception with no message or cause.
     */
    public TransactionProcessingException() {

        super();
    }

    /**
     * Constructor with a message. Initializes a new instance of the exception with the provided message.
     *
     * @param message The detail message for the exception.
     */
    public TransactionProcessingException(String message) {

        super(message);
    }

    /**
     * Constructor with a message and cause. Initializes a new instance of the exception with the provided message and
     * cause.
     *
     * @param message The detail message for the exception.
     * @param cause The cause of the exception (can be retrieved later).
     */
    public TransactionProcessingException(String message, Throwable cause) {

        super(message, cause);
    }

    /**
     * Constructor with a cause. Initializes a new instance of the exception with the provided cause.
     *
     * @param cause The cause of the exception (can be retrieved later).
     */
    public TransactionProcessingException(Throwable cause) {

        super(cause);
    }

    /**
     * Constructor with a message, cause, and additional options. Initializes a new instance of the exception with the
     * provided message, cause, suppression enabled, and stack trace writable.
     *
     * @param message The detail message for the exception.
     * @param cause The cause of the exception (can be retrieved later).
     * @param enableSuppression Whether suppression is enabled for the exception.
     * @param writableStackTrace Whether the stack trace should be writable.
     */
    public TransactionProcessingException(String message, Throwable cause, boolean enableSuppression,
                                          boolean writableStackTrace) {

        super(message, cause, enableSuppression, writableStackTrace);
    }
}
