package com.pwc.mastercard_ddf_service.exception;

import com.pwc.mastercard_ddf_service.domain.ErrorResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

/**
 * Global exception handler that catches and handles custom exceptions, returning appropriate HTTP responses with error
 * details.
 */
@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    /**
     * Handles TransactionProcessingException and FileProcessingException.
     *
     * @param exception The exception that was thrown.
     * @return ResponseEntity containing the error response and appropriate HTTP status.
     */
    @ExceptionHandler({TransactionProcessingException.class, FileProcessingException.class})
    public ResponseEntity<ErrorResponse> handleTransactionAndFileProcessingExceptions(RuntimeException exception) {

        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setErrorMessage(exception.getMessage());
        log.error("Exception occurred while processing: ", exception);
        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR); // 500 Internal Server Error
    }

    /**
     * Handles StorageProcessingException.
     *
     * @param exception The exception that was thrown.
     * @return ResponseEntity containing the error response and appropriate HTTP status.
     */
    @ExceptionHandler(StorageDataProcessingException.class)
    public ResponseEntity<ErrorResponse> handleStorageProcessingException(StorageDataProcessingException exception) {

        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setErrorMessage(exception.getMessage());
        log.error("Error in storage processing: ", exception);
        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST); // 400 Bad Request (for client-side errors)
    }

    /**
     * Handles InvalidTransactionDataException.
     *
     * @param exception The exception that was thrown.
     * @return ResponseEntity containing the error response and appropriate HTTP status.
     */
    @ExceptionHandler(InvalidTransactionDataException.class)
    public ResponseEntity<ErrorResponse> handleInvalidTransactionDataException(
            InvalidTransactionDataException exception) {

        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setErrorMessage(exception.getMessage());
        log.error("Invalid transaction data: ", exception);
        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST); // 400 Bad Request
    }

    /**
     * Handles general exceptions.
     *
     * @param exception The exception that was thrown.
     * @return ResponseEntity containing the error response and appropriate HTTP status.
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGeneralException(Exception exception) {

        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setErrorMessage("An unexpected error occurred");
        log.error("Unexpected error occurred: ", exception);
        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR); // 500 Internal Server Error
    }
}
