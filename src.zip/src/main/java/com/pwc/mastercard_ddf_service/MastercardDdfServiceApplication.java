package com.pwc.mastercard_ddf_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * Entry point for the Mastercard DDF (Data Distribution Framework) Service Spring Boot application.
 *
 * <p>This class initializes and runs the Spring application context, scanning the specified
 * base package for components and configuration classes.</p>
 */
@SpringBootApplication
@ComponentScan(basePackages = "com.pwc")
public class MastercardDdfServiceApplication {

    /**
     * Main method that launches the Spring Boot application.
     *
     * @param args command-line arguments passed to the application
     */
    public static void main(String[] args) {

        SpringApplication.run(MastercardDdfServiceApplication.class, args);
    }

}
