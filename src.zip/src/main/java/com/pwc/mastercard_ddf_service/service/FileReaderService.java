package com.pwc.mastercard_ddf_service.service;

import java.io.IOException;

/**
 * The {@code FileReaderService} interface defines the contract for services that
 * read, process, and save files from a source (e.g., Azure Blob Storage).
 *
 * <p>Implementations of this interface are responsible for handling file input,
 * transforming data, and persisting output in a desired format or location.</p>
 */
public interface FileReaderService {

    /**
     * Reads a file from the provided source, processes its content, and saves the result.
     *
     * @param sourceFileName the full path or name of the source file to be processed
     * @throws IOException if an I/O error occurs during reading or writing
     */
    void processAndSaveFile(String sourceFileName) throws IOException;
}
