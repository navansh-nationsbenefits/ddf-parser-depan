package com.pwc.mastercard_ddf_service.service.impl;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.specialized.BlockBlobClient;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pwc.mastercard_ddf_service.config.BatchConfig;
import com.pwc.mastercard_ddf_service.config.FieldMappingConfig;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.BATCH_PREPARATION_FAILED;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.CHAR_EIGHT;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.COMPLETED_UPLOADING_BLOCKS;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.DATE_TIME_FORMAT_YYYY_MM_DD;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.DOT_JSON_EXTENTION;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.DUPLICATE_TRANSACTION_SKIPPED;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.EMPTY_STRING;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.ENRICHED_DDF_FILE;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.ERROR_PROCESSING_FILE_IN_BACKGROUND;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.ERROR_WRITING_BATCH_TO_BLOB;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.FAILED_TO_FLUSH_CHUNK_TO_BLOB;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.FILE_PROCESSING_FAILED;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.FILE_READER;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.FINISHED_PROCESSING_TRANSACTION_IN_SECONDS;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.FOURTEEN;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.HYPHEN;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.INVALID_TRANSACTION_DATA;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.MASKED_PAN_STRING;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.ONE;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.ONE_ZERO_TWO_FOUR;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.PAN;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.PROCESSED_BATCH_OF_TRANSACTION_AND_TOTAL;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.SIXTEEN;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.SKIPPED_HEADER;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.SKIPPING_EMPTY_BATCH;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.SOURCE_FILE_NOT_FOUND;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.STARTING_PROCESSING_FILE;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.THIRTY;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.THIRTY_THREE;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.THOUSAND;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.TRANSACTION;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.TRANSACTION_NUMBER;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.TRANSACTION_PROCESSING_FAILED;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.TWENTY_FOUR;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.TWO;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.UNDERSCORE_STRING;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.UPLOADED_CHUNK_OF_SIZE_BYTES;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.ZERO;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.ZERO_ONE;
import com.pwc.mastercard_ddf_service.domain.TransactionProcessingContext;
import com.pwc.mastercard_ddf_service.dto.TransactionData;
import com.pwc.mastercard_ddf_service.exception.BatchPreparationException;
import com.pwc.mastercard_ddf_service.exception.FileProcessingException;
import com.pwc.mastercard_ddf_service.exception.StorageDataProcessingException;
import com.pwc.mastercard_ddf_service.exception.StorageUploadException;
import com.pwc.mastercard_ddf_service.exception.TransactionBatchProcessingException;
import com.pwc.mastercard_ddf_service.exception.TransactionProcessingException;
import com.pwc.mastercard_ddf_service.service.FileReaderService;
import lombok.RequiredArgsConstructor;
import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import static org.springdoc.core.utils.Constants.NULL;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;


/**
 * Implementation of {@link FileReaderService} that processes text-based transaction files from Azure Blob Storage,
 * transforms and enriches the data, and saves it back to a configured output blob container in JSON format.
 *
 * <p>This service supports parallel transaction processing, de-duplication, and chunked writing to blobs
 * using Azure's BlockBlobClient.</p>
 */
@Service(FILE_READER)
@RequiredArgsConstructor
public class FileReaderServiceImpl implements FileReaderService {

    private static final Logger log = LoggerFactory.getLogger(FileReaderServiceImpl.class);
    private final BlobContainerClient blobContainerClient;
    private final BlobContainerClient enrichedBlobContainerClient;
    private final ObjectMapper objectMapper;
    private final BatchConfig batchConfig;
    private final FieldMappingConfig fieldMappingConfig;

    /**
     * Validates the existence of a transaction file in Azure Blob Storage and, if found, initiates asynchronous
     * processing of the file. The processing includes reading, enriching, and writing data back to a separate output
     * container in chunked format. This method returns immediately after validation.
     *
     * <p>The actual processing is offloaded to a background thread using CompletableFuture and does not block the
     * caller.</p>
     *
     * @param sourceFileFullPath the full path of the source file in the blob container
     * @exception FileNotFoundException if the specified file does not exist in the blob storage
     */
    @Override
    public void processAndSaveFile(String sourceFileFullPath) throws FileNotFoundException {

        String fileName = Paths.get(sourceFileFullPath).getFileName().toString();
        BlobClient sourceBlobClient = blobContainerClient.getBlobClient(fileName);

        if(Boolean.FALSE.equals(sourceBlobClient.exists())) {
            throw new FileNotFoundException(SOURCE_FILE_NOT_FOUND+fileName);
        }
        log.info(STARTING_PROCESSING_FILE, fileName);

        CompletableFuture.runAsync(() -> {
            try {
                performFileProcessing(sourceFileFullPath, fileName);
            } catch(Exception e) {
                log.error(ERROR_PROCESSING_FILE_IN_BACKGROUND, fileName, e);
            }
        });
    }

    /**
     * Processes a transaction file by reading it line-by-line from Azure Blob Storage, parsing and enriching each
     * transaction, and writing the transformed output as chunked JSON into another Azure Blob container.
     *
     * <p>This method is intended to run in a background thread. It handles batching, transaction de-duplication,
     * chunk flushing, and final block commit. Each transaction is parsed and processed based on its record
     * structure.</p>
     *
     * @param sourceFileFullPath the full path of the source file to be processed
     * @param fileName the file name extracted from the full path, used for blob read operations
     * @exception FileProcessingException if an error occurs during file I/O, chunk upload, or processing
     */
    private void performFileProcessing(String sourceFileFullPath, String fileName) {

        long startTime = System.currentTimeMillis();
        Set<String> seenTransactionIds = ConcurrentHashMap.newKeySet();

        //batchSize is used to push transactions to azure blob
        int batchSize = batchConfig.getTransaction();

        TransactionProcessingContext context = initializeProcessingContext(sourceFileFullPath);

        try(ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();

                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(blobContainerClient.getBlobClient(fileName).openInputStream(),
                                              StandardCharsets.UTF_8))) {

            prepareAndSubmitTransactionBatches(reader, batchSize, executor, context, seenTransactionIds);

            awaitTerminationAndCommitChunks(executor, context);

        } catch(Exception e) {
            throw new FileProcessingException(FILE_PROCESSING_FAILED, e);
        }
        long durationInSeconds = (System.currentTimeMillis()-startTime) / THOUSAND;

        log.info(FINISHED_PROCESSING_TRANSACTION_IN_SECONDS, context.getTransactionCounter().get(), durationInSeconds);

    }

    /**
     * Initializes and prepares the context required for processing the transaction file.
     * <p>
     * This includes:
     * <ul>
     *     <li>Generating a unique output blob name based on the input file path and timestamp</li>
     *     <li>Creating a {@link BlockBlobClient} for writing to Azure Blob Storage</li>
     *     <li>Initializing a synchronized list to collect block IDs during chunked uploads</li>
     *     <li>Creating an {@link AtomicInteger} to track total transactions processed</li>
     * </ul>
     *
     * @param sourceFileFullPath the full path of the source input file
     * @return a fully populated {@link TransactionProcessingContext} used during file processing
     */
    private TransactionProcessingContext initializeProcessingContext(String sourceFileFullPath) {

        String outputFileName = ENRICHED_DDF_FILE+sourceFileFullPath.replaceFirst("\\.(txt)$", UNDERSCORE_STRING)+
                LocalDateTime.now().format(DateTimeFormatter.ofPattern(DATE_TIME_FORMAT_YYYY_MM_DD))+DOT_JSON_EXTENTION;

        BlockBlobClient blobClient = enrichedBlobContainerClient.getBlobClient(outputFileName).getBlockBlobClient();

        List<String> blockIds = Collections.synchronizedList(new ArrayList<>());
        AtomicInteger transactionCounter = new AtomicInteger(0);

        return new TransactionProcessingContext(blobClient, blockIds, transactionCounter);
    }


    /**
     * Reads the transaction file line-by-line, groups lines into individual transactions, batches them based on the
     * configured batch size, and submits them asynchronously for processing.
     *
     * @param reader the {@link BufferedReader} used to read the input file
     * @param batchSize the number of transactions per batch
     * @param executor the {@link ExecutorService} responsible for parallel processing
     * @param context the shared {@link TransactionProcessingContext} for blob upload tracking
     * @param seenTransactionIds a thread-safe set used to skip duplicate transactions
     */
    private void prepareAndSubmitTransactionBatches(BufferedReader reader, int batchSize, ExecutorService executor,
                                                    TransactionProcessingContext context,
                                                    Set<String> seenTransactionIds){

        try {
            String ignoredHeader = reader.readLine();
            log.debug(SKIPPED_HEADER, ignoredHeader);

            List<List<String>> transactionBatch = new ArrayList<>();
            List<String> currentTransaction = new ArrayList<>();
            String line;

            while((line = reader.readLine()) != null) {
                // break loop once trailer record is reached
                if(line.charAt(ZERO) == CHAR_EIGHT) {
                    break;
                }
                String recordType = line.substring(ZERO, TWO);
                // if new transaction is reached add current transaction in transaction batch
                if(ZERO_ONE.equals(recordType) && !currentTransaction.isEmpty()) {
                    transactionBatch.add(new ArrayList<>(currentTransaction));
                    currentTransaction.clear();
                    // submitting batch if batch size is full
                    if(transactionBatch.size() >= batchSize) {
                        submitTransactionBatch(executor, new ArrayList<>(transactionBatch), context,
                                               seenTransactionIds);
                        transactionBatch.clear();
                    }
                }
                // add records to current transaction
                currentTransaction.add(line);
            }
            // after loop ends check for any unbatched transactions
            if(!currentTransaction.isEmpty()) {
                transactionBatch.add(new ArrayList<>(currentTransaction));
            }
            // submit the final batch of transactions
            if(!transactionBatch.isEmpty()) {
                submitTransactionBatch(executor, new ArrayList<>(transactionBatch), context, seenTransactionIds);
            }
        } catch(Exception e) {
            log.error(BATCH_PREPARATION_FAILED, e.getMessage(), e);
            throw new BatchPreparationException(BATCH_PREPARATION_FAILED, e);
        }
    }


    /**
     * Processes a batch of raw transactions by transforming them into {@link TransactionData} objects, skipping any
     * duplicates, and flushing the batch to Azure Blob Storage as a single chunk.
     *
     * @param executor the {@link ExecutorService} handling async execution
     * @param transactionBatch the list of raw transactions, where each transaction is a list of lines
     * @param context the {@link TransactionProcessingContext} containing blob client, block IDs, and
     *         transaction counter
     * @param seenTransactionIds the set used to detect and skip duplicate transaction numbers
     */

    private void submitTransactionBatch(ExecutorService executor, List<List<String>> transactionBatch,
                                        TransactionProcessingContext context, Set<String> seenTransactionIds) {

        executor.submit(() -> {
            try {
                List<TransactionData> processedBatch = new ArrayList<>();
                //de-pan the transactions
                for(List<String> rawTransaction : transactionBatch) {
                    TransactionData data = processTransaction(rawTransaction, seenTransactionIds);
                    if(data != null) {
                        processedBatch.add(data);
                    }
                }
                int batchSize = processedBatch.size();
                int totalCount = context.getTransactionCounter().addAndGet(batchSize);
                //check if processed batch is empty
                if(processedBatch.isEmpty()) {
                    log.warn(SKIPPING_EMPTY_BATCH);
                    return;
                }
                // write the processed batch as NDJSON and upload to blob
                writeTransactionsToBlobChunk(processedBatch, context.getBlockBlobClient(), context.getBlockIds());
                log.info(PROCESSED_BATCH_OF_TRANSACTION_AND_TOTAL, batchSize, totalCount);

            } catch(Exception e) {
                log.error(TRANSACTION_PROCESSING_FAILED, e);
                throw new TransactionBatchProcessingException(TRANSACTION_PROCESSING_FAILED, e);
            }
        });
    }

    /**
     * Transforms raw transaction lines into a {@link TransactionData} object, applying de-duplication and PAN hashing.
     *
     * @param lines the list of transaction record lines
     * @param seenTransactionIds a set to track and skip duplicate transaction IDs
     * @return the processed {@link TransactionData} or null if it's a duplicate
     */
    private TransactionData processTransaction(List<String> lines, Set<String> seenTransactionIds) {

        try {
            List<String> recordList = new ArrayList<>();
            String transactionNumber = NULL;
            String hashedPan = NULL;

            for(String line : lines) {
                // Identify record type by parsing the first two characters of the line
                int recordNumber = Integer.parseInt(line.substring(ZERO, TWO));
                // Process first record of the transaction
                if(recordNumber == ONE) {
                    transactionNumber = extractField(line, TRANSACTION_NUMBER, ONE);
                    String pan = extractField(line, PAN, ONE);
                    // Hash the PAN for security
                    hashedPan = DigestUtils.sha256Hex(pan);
                    // Mask the PAN in the line and add it to the record list
                    String maskedLine = line.substring(ZERO, FOURTEEN)+MASKED_PAN_STRING+line.substring(THIRTY_THREE);
                    recordList.add(maskedLine);
                } else {
                    // Add other records as it is
                    recordList.add(line);
                }
            }
            // Skip duplicates using a transaction ID cache
            if(!seenTransactionIds.add(transactionNumber)) {
                log.warn(DUPLICATE_TRANSACTION_SKIPPED, transactionNumber);
                return null;
            }
            // Return the processed transaction data
            return new TransactionData(transactionNumber, hashedPan, recordList);
        } catch(Exception e) {
            log.error(INVALID_TRANSACTION_DATA, e.getMessage(), e);
            throw new TransactionProcessingException(INVALID_TRANSACTION_DATA, e);
        }
    }

    /**
     * Writes a batch of {@link TransactionData} objects to a memory buffer as NDJSON, then uploads the resulting chunk
     * to Azure Blob Storage if it contains any data.
     *
     * @param batch the list of processed transactions to write
     * @param blobClient the {@link BlockBlobClient} used to stage the blob chunk
     * @param blockIds the synchronized list used to track all uploaded block IDs
     */

    private void writeTransactionsToBlobChunk(List<TransactionData> batch, BlockBlobClient blobClient,
                                              List<String> blockIds) {

        try(ByteArrayOutputStream chunk = new ByteArrayOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(chunk, StandardCharsets.UTF_8),
                                                           SIXTEEN * ONE_ZERO_TWO_FOUR)) {
            // Write Transaction data to writer
            for(TransactionData data : batch) {
                writer.write(objectMapper.writeValueAsString(data));
                writer.newLine();
            }

            writer.flush();
            // Check if chunk size is not ZERO
            if(chunk.size() > ZERO) {
                uploadBlobChunk(blobClient, blockIds, chunk);
            }

        } catch(IOException e) {
            log.error(ERROR_WRITING_BATCH_TO_BLOB, e);
            throw new StorageDataProcessingException(ERROR_WRITING_BATCH_TO_BLOB, e);
        }
    }

    /**
     * Uploads a chunk of transaction data to Azure Blob Storage as a single block using
     * {@link BlockBlobClient#stageBlock}.
     *
     * @param blobClient the {@link BlockBlobClient} used to upload the chunk
     * @param blockIds the synchronized list used to track all uploaded block IDs
     * @param chunk the byte buffer containing the serialized transaction data to upload
     */

    private void uploadBlobChunk(BlockBlobClient blobClient, List<String> blockIds, ByteArrayOutputStream chunk) {

        try {
            // Use a safe block ID: 24 bytes, US-ASCII, then Base64
            String rawBlockId = UUID.randomUUID().toString().replace(HYPHEN, EMPTY_STRING).substring(ZERO, TWENTY_FOUR);
            String blockId = Base64.getEncoder().encodeToString(rawBlockId.getBytes(StandardCharsets.US_ASCII));
            // stream chunk block to blob
            blobClient.stageBlock(blockId, new ByteArrayInputStream(chunk.toByteArray()), chunk.size());
            blockIds.add(blockId);

            log.info(UPLOADED_CHUNK_OF_SIZE_BYTES, chunk.size());

        } catch(Exception e) {
            log.error(FAILED_TO_FLUSH_CHUNK_TO_BLOB, e);
            throw new StorageUploadException(FAILED_TO_FLUSH_CHUNK_TO_BLOB, e);
        }
    }

    /**
     * Waits for all submitted transaction processing tasks to complete, then commits the uploaded blob chunks to
     * finalize the Azure blob.
     *
     * @param executor the {@link ExecutorService} responsible for transaction batch threads
     * @param context the {@link TransactionProcessingContext} holding the blob client and block IDs
     * @exception InterruptedException if the await operation is interrupted
     */

    private void awaitTerminationAndCommitChunks(ExecutorService executor, TransactionProcessingContext context)
            throws InterruptedException {
        // wait for executor to shut down
        executor.shutdown();
        if(!executor.awaitTermination(THIRTY, TimeUnit.MINUTES)) {
            executor.shutdownNow();
        }
        // commit uploaded blobs to blob storage
        context.getBlockBlobClient().commitBlockList(context.getBlockIds());
        log.info(COMPLETED_UPLOADING_BLOCKS, context.getBlockIds().size());
    }


    /**
     * Extracts a specific field value from a given line using the mapping rules.
     *
     * @param line the full line from the input file
     * @param fieldName the field name to extract (e.g. "transaction_number")
     * @param recordNumber the record number (e.g. 1 for transaction header)
     * @return the extracted substring or an empty string if not found
     */
    private String extractField(String line, String fieldName, int recordNumber) {

        return fieldMappingConfig.getFieldMappings().stream()
                .filter(f -> f.getFieldName().equals(fieldName) && f.getRecordNumber() == recordNumber &&
                        f.getRecordType().equals(TRANSACTION)).findFirst().map(f -> {
                    int start = f.getStart();
                    int end = start+f.getLength();
                    return line.length() >= end ? line.substring(start, end) : EMPTY_STRING;
                }).orElse(EMPTY_STRING);
    }
}
//azure.enriched.storage.account-key=GsMvrslPzSyaysiscBLxj5t2ArYMoeIi1KgX+cQpq07en52t23+S3ti64kNx/QEiHGVxpJAqAyEP+AStvYqhoQ==;azure.enriched.storage.account-name=iglooddf;azure.enriched.storage.connection-string=DefaultEndpointsProtocol=https\;AccountName=iglooddf\;AccountKey=GsMvrslPzSyaysiscBLxj5t2ArYMoeIi1KgX+cQpq07en52t23+S3ti64kNx/QEiHGVxpJAqAyEP+AStvYqhoQ==\;EndpointSuffix=core.windows.net;azure.enriched.storage.container-name=ddf;azure.storage.account-key=PdA1sU2NxC6XdOjZFripnVq1NluSQ5OVf+tFneAjN3+Lq0eFkdt9faVJeYZkQM6GV3w3m1nbYhrH+AStPfS9xQ==;azure.storage.account-name=mcddf;azure.storage.connection-string=DefaultEndpointsProtocol=https\;AccountName=mcddf\;AccountKey=PdA1sU2NxC6XdOjZFripnVq1NluSQ5OVf+tFneAjN3+Lq0eFkdt9faVJeYZkQM6GV3w3m1nbYhrH+AStPfS9xQ==\;EndpointSuffix=core.windows.net;azure.storage.container-name=ddf
