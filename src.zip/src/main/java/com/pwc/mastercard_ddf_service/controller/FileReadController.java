package com.pwc.mastercard_ddf_service.controller;

import com.pwc.mastercard_ddf_service.FileServiceFactory;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.FILE_PROCESSING_FAILED;
import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.REQUEST_RECEIVED_SUCCESSFULLY;
import com.pwc.mastercard_ddf_service.dto.FileRequest;
import com.pwc.mastercard_ddf_service.exception.FileProcessingException;
import com.pwc.mastercard_ddf_service.service.FileReaderService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.List;

/**
 * REST controller for handling requests related to reading and processing files stored
 * in Azure Blob Storage.
 *
 * <p>This controller receives file read requests and delegates the processing to appropriate
 * {@link FileReaderService} implementations based on the file type.</p>
 */
@RestController
@RequestMapping("/blob")
public class FileReadController {

    private final FileServiceFactory fileServiceFactory;

    /**
     * Constructs a new {@code FileReadController} with the provided services.
     *
     * @param fileServiceFactory the factory used to retrieve appropriate file reader services
     *                           based on file type
     */
    public FileReadController(FileServiceFactory fileServiceFactory) {
        this.fileServiceFactory = fileServiceFactory;
    }

    /**
     * Processes a list of file read requests by delegating to the appropriate {@link FileReaderService}
     * based on the type specified in each request.
     *
     * @param fileRequest the list of file read requests containing subject and type information
     * @return a {@link ResponseEntity} indicating the overall success of the operation
     * @throws RuntimeException if file processing fails for any request
     */
    @PostMapping("/read")
    public ResponseEntity<String> readFile(@RequestBody List<FileRequest> fileRequest) {
        fileRequest.forEach(request -> {
            try {
                String type = request.getType();
                FileReaderService service = fileServiceFactory.getService(type);
                service.processAndSaveFile(request.getSubject());
            } catch (IOException e) {
                throw new FileProcessingException(FILE_PROCESSING_FAILED + e.getMessage());
            }
        });
        return ResponseEntity.ok(REQUEST_RECEIVED_SUCCESSFULLY);
    }
}
