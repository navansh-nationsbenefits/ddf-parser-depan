package com.pwc.mastercard_ddf_service.constants;

import lombok.experimental.UtilityClass;

/**
 * The type File processor constants.
 */
@UtilityClass
public class FileProcessorConstants {

    /**
     * The constant ONE.
     */
    public static final Integer ONE = 1;

    /**
     * The constant TWO.
     */
    public static final Integer TWO = 2;

    /**
     * The constant FOURTEEN.
     */
    public static final Integer FOURTEEN = 14;

    /**
     * The constant THIRTY_THREE.
     */
    public static final Integer THIRTY_THREE = 33;


    /**
     * The constant RECORD_NUMBER_ONE.
     */
    public static final char CHAR_EIGHT = '8';


    /**
     * The constant DOT_JSON_EXTENTION.
     */
    public static final String DOT_JSON_EXTENTION = ".json";

    /**
     * The constant DATE_TIME_FORMAT_YYYY_MM_DD.
     */
    public static final String DATE_TIME_FORMAT_YYYY_MM_DD = "yyyy-MM-dd_hh-mm-ss";

    /**
     * The constant UNDERSCORE_STRING.
     */
    public static final String UNDERSCORE_STRING = "_";

    /**
     * The constant ENRICHED_DDF_FILE.
     */
    public static final String ENRICHED_DDF_FILE = "enriched_ddf_";

    /**
     * The constant ZERO.
     */
    public static final Integer ZERO = 0;

    /**
     * The constant TWENTY_FOUR.
     */
    public static final Integer TWENTY_FOUR = 24;

    /**
     * The constant THOUSAND.
     */
    public static final Integer THOUSAND = 1000;

    /**
     * The constant ZERO_ONE.
     */
    public static final String ZERO_ONE = "01";


    /**
     * The constant SIXTEEN.
     */
    public static final Integer SIXTEEN = 16;

    /**
     * The constant ONE_ZERO_TWO_FOUR.
     */
    public static final Integer ONE_ZERO_TWO_FOUR = 1024;

    /**
     * The constant THIRTY.
     */
    public static final Integer THIRTY = 30;

    /**
     * The constant UPLOADED_CHUNK_OF_SIZE_BYTES.
     */
    public static final String UPLOADED_CHUNK_OF_SIZE_BYTES = "Uploaded chunk of size {} bytes";

    /**
     * The constant FINISHED_PROCESSING_TRANSACTION_IN_SECONDS.
     */
    public static final String FINISHED_PROCESSING_TRANSACTION_IN_SECONDS =
            "Finished processing {} transactions in {} seconds.";

    /**
     * The constant TRANSACTION_PROCESSING_FAILED.
     */
    public static final String TRANSACTION_PROCESSING_FAILED = "Transaction processing failed";

    /**
     * The constant BATCH_PREPARATION_FAILED.
     */
    public static final String BATCH_PREPARATION_FAILED = "Batch preparation failed: {}";

    /**
     * The constant SOURCE_FILE_NOT_FOUND.
     */
    public static final String SOURCE_FILE_NOT_FOUND = "Source file not found: ";

    /**
     * The constant STARTING_PROCESSING_FILE.
     */
    public static final String STARTING_PROCESSING_FILE = "Starting processing file: {}";

    /**
     * The constant COMPLETED_UPLOADING_BLOCKS.
     */
    public static final String COMPLETED_UPLOADING_BLOCKS = "Completed uploading {} blocks.";

    /**
     * The constant FILE_PROCESSING_FAILED.
     */
    public static final String FILE_PROCESSING_FAILED = "File processing failed: ";

    /**
     * The constant MASKED_PAN_STRING.
     */
    public static final String MASKED_PAN_STRING = "XXXXXXXXXXXXXXXXXXX";

    /**
     * The constant DUPLICATE_TRANSACTION_SKIPPED.
     */
    public static final String DUPLICATE_TRANSACTION_SKIPPED = "Duplicate transaction skipped: {}";

    /**
     * The constant FILE_READER.
     */
    public static final String FILE_READER = "FileReader";

    /**
     * The constant INVALID_TRANSACTION_DATA.
     */
    public static final String INVALID_TRANSACTION_DATA = "Invalid transaction data: {}";

    /**
     * The constant EMPTY_STRING.
     */
    public static final String EMPTY_STRING = "";

    /**
     * The constant TRANSACTION.
     */
    public static final String TRANSACTION = "transaction";

    /**
     * The constant TRANSACTION_NUMBER.
     */
    public static final String TRANSACTION_NUMBER = "transaction_number";

    /**
     * The constant PAN.
     */
    public static final String PAN = "pan";

    /**
     * The constant FIELD_MAPPING_FILE.
     */
    public static final String FIELD_MAPPING_FILE = "fieldMapping.json";

    /**
     * The constant ERROR_PROCESSING_FILE_IN_BACKGROUND.
     */
    public static final String ERROR_PROCESSING_FILE_IN_BACKGROUND = "Error processing file in background: {}";

    /**
     * The constant SKIPPING_EMPTY_BATCH.
     */
    public static final String SKIPPING_EMPTY_BATCH = "Skipping empty batch (all transactions filtered or duplicates)";

    /**
     * The constant PROCESSED_BATCH_OF_TRANSACTION_AND_TOTAL.
     */
    public static final String PROCESSED_BATCH_OF_TRANSACTION_AND_TOTAL =
            "Processed batch of {} transactions, total so far: {}";

    /**
     * The constant ERROR_WRITING_BATCH_TO_BLOB.
     */
    public static final String ERROR_WRITING_BATCH_TO_BLOB = "Error writing batch to blob";

    /**
     * The constant FAILED_TO_FLUSH_CHUNK_TO_BLOB.
     */
    public static final String FAILED_TO_FLUSH_CHUNK_TO_BLOB = "Failed to flush chunk to blob";

    /**
     * The constant HYPHEN.
     */
    public static final String HYPHEN = "-";

    /**
     * The constant FIELD_MAPPING_FILE_NOT_FOUND.
     */
    public static final String FIELD_MAPPING_FILE_NOT_FOUND = "fieldMapping.json not found in classpath";

    /**
     * The constant LOADED_FIELD_MAPPING.
     */
    public static final String LOADED_FIELD_MAPPING = "Loaded {} field mappings";

    /**
     * The constant SKIPPED_HEADER.
     */
    public static final String SKIPPED_HEADER = "Skipped header: {}";

    /**
     * The constant REQUEST_RECEIVED_SUCCESSFULLY.
     */
    public static final String REQUEST_RECEIVED_SUCCESSFULLY = "Request received successfully";
}
