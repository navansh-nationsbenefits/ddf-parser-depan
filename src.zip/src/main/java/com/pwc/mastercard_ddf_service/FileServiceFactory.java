package com.pwc.mastercard_ddf_service;

import com.pwc.mastercard_ddf_service.service.FileReaderService;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Factory class responsible for retrieving the appropriate {@link FileReaderService}
 * implementation based on a specified type.
 *
 * <p>This factory is managed by Spring as a component and is designed to be injected wherever
 * dynamic resolution of {@link FileReaderService} implementations is required.</p>
 */
@Component
public class FileServiceFactory {

    private final Map<String, FileReaderService> fileReaderServiceMap;


    /**
     * Constructs an instance of {@code AzureFunctionFactory} with a mapping of service types to their
     * corresponding {@link FileReaderService} implementations.
     *
     * @param fileReaderServiceMap a map where the key is the service type identifier and the
     *                             value is the corresponding {@link FileReaderService} implementation
     */
    public FileServiceFactory(Map<String, FileReaderService> fileReaderServiceMap) {
        this.fileReaderServiceMap = fileReaderServiceMap;
    }

    /**
     * Retrieves a {@link FileReaderService} implementation based on the provided type.
     *
     * @param type the identifier for the service type
     * @return the {@link FileReaderService} corresponding to the given type
     * @throws IllegalArgumentException if no service is found for the specified type
     */
    public FileReaderService getService(String type) {
        FileReaderService service = fileReaderServiceMap.get(type);
        if (service == null) {
            throw new IllegalArgumentException("No FileService found for type" + type);
        }
        return service;
    }
}
