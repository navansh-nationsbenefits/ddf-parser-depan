package com.pwc.mastercard_ddf_service.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * Represents transformed transaction data extracted or processed from a source file.
 *
 * <p>This class holds key transaction details such as transaction number, PAN, and
 * a list of related records.</p>
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TransactionData {

    /**
     * A unique identifier representing the transaction.
     */
    private String transactionNumber;

    /**
     * The Primary Account Number (PAN) associated with the transaction.
     */
    private String pan;

    /**
     * A list of additional records or data entries related to the transaction.
     */
    private List<String> recordList;
}
