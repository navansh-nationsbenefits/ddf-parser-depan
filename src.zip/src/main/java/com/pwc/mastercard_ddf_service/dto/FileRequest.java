package com.pwc.mastercard_ddf_service.dto;

import com.pwc.mastercard_ddf_service.service.FileReaderService;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * Represents a request to process a file from Azure Blob Storage or similar sources.
 *
 * <p>This class contains metadata about the file, including its type, event information,
 * and associated data such as the file's URL.</p>
 */
@Getter
@Setter
public class FileRequest {

    /**
     * The type of the file, used to determine which {@link FileReaderService} should process it.
     */
    private String type;

    /**
     * The type of event that triggered the request (e.g., BlobCreated, BlobDeleted).
     */
    private String eventType;

    /**
     * The subject or identifier for the file, often representing the blob path.
     */
    private String subject;

    /**
     * The time at which the event related to this request occurred.
     */
    private LocalDateTime eventTime;

    /**
     * Additional data associated with the request, typically including the file's URL.
     */
    private Data data;
}