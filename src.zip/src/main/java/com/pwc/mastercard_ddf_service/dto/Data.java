package com.pwc.mastercard_ddf_service.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * Represents a data model containing a single URL field.
 *
 * <p>This class can be used to encapsulate URL-related information passed
 * between different layers or components of the application.</p>
 */
@Getter
@Setter
public class Data {

    /**
     * The URL associated with this data object.
     */
    private String url;
}
