package com.pwc.mastercard_ddf_service.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Represents a field definition used to parse fixed-length records from a file.
 * This model is populated from the field-mapping JSON in the resources folder.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FieldMapping {

    private String recordType;
    private String fieldName;
    private int start;
    private int length;
    private int recordNumber;
}
