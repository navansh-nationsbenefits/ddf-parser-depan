package com.pwc.mastercard_ddf_service.domain;

import com.azure.storage.blob.specialized.BlockBlobClient;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Context holder for transaction processing operations.
 * <p>
 * Encapsulates all shared resources required for writing, batching,
 * and uploading transaction data.
 */
@Getter
@Setter
public class TransactionProcessingContext {

    private final BlockBlobClient blockBlobClient;
    private final List<String> blockIds;
    private final AtomicInteger transactionCounter;

    /**
     * Constructs a new context for processing and batching transactions.
     *
     * @param blockBlobClient  the Azure block blob client for uploading data
     * @param blockIds         the list of staged block IDs
     */
    public TransactionProcessingContext(
                                        BlockBlobClient blockBlobClient,
                                        List<String> blockIds,
                                        AtomicInteger transactionCounter) {
        this.blockBlobClient = blockBlobClient;
        this.blockIds = blockIds;
        this.transactionCounter = transactionCounter;
    }

}

