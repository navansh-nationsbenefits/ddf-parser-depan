package com.pwc.mastercard_ddf_service.domain;

import com.azure.storage.blob.specialized.BlockBlobClient;
import com.pwc.mastercard_ddf_service.dto.TransactionData;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
public class TransactionProcessingState {
    private Set<String> seenTransactionIds;
    private int batchSize;
    private List<TransactionData> batchBuffer;
    private BlockBlobClient blockBlobClient;
    private List<String> blockIds;
    private ByteArrayOutputStream currentChunk;
    private BufferedWriter writer;
    private TransactionProcessingContext context;
}

