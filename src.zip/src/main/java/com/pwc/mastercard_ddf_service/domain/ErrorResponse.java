package com.pwc.mastercard_ddf_service.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ErrorResponse implements Serializable {

    private static final long serialVersionUID = -8753412865429986532L;

    private String errorCode;

    private String errorMessage;
}
