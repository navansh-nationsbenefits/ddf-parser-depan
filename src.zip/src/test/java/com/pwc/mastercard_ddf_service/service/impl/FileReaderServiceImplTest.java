package com.pwc.mastercard_ddf_service.service.impl;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.models.BlockBlobItem;
import com.azure.storage.blob.specialized.BlobInputStream;
import com.azure.storage.blob.specialized.BlockBlobClient;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pwc.mastercard_ddf_service.config.BatchConfig;
import com.pwc.mastercard_ddf_service.config.FieldMappingConfig;
import com.pwc.mastercard_ddf_service.domain.FieldMapping;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import static com.pwc.mastercard_ddf_service.constants.FileProcessorConstants.SOURCE_FILE_NOT_FOUND;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

/**
 * Unit tests for {@link FileReaderServiceImpl}, verifying file processing and initialization logic.
 *
 * <p>This test class focuses on validating:
 * <ul>
 *     <li>Asynchronous transaction file processing from Azure Blob Storage</li>
 *     <li>Error handling for missing blob clients</li>
 *     <li>Proper deserialization of field mappings from a JSON resource</li>
 * </ul>
 *
 * <p>The class uses Mockito for mocking external dependencies and JUnit 5 for assertions and test structure.
 * All I/O interactions with Azure Blob Storage and JSON parsing via {@code ObjectMapper} are isolated.
 *
 * <p>Key scenarios tested:
 * <ul>
 *     <li>Happy path with real test file content</li>
 *     <li>Failure scenario for missing blob client</li>
 *     <li>Correct parsing of field mapping configuration</li>
 * </ul>
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class FileReaderServiceImplTest {

    @Spy
    @InjectMocks
    private FileReaderServiceImpl fileReaderService;

    @Mock
    private BlobContainerClient blobContainerClient;
    @Mock
    private BlobContainerClient enrichedBlobContainerClient;
    @Mock
    private BlobClient blobClient;
    @Mock
    private BlockBlobClient blockBlobClient;
    @Mock
    private BatchConfig batchConfig;
    @Mock
    private ObjectMapper objectMapper;
    @Mock
    private BlockBlobItem blockBlobItem;
    @Mock
    private BlobInputStream blobInputStream;
    @Mock
    private FieldMappingConfig fieldMappingConfig;

    @BeforeEach
    void init() throws Exception {

        when(blobContainerClient.getBlobClient(anyString())).thenReturn(blobClient);
        when(blobClient.getBlockBlobClient()).thenReturn(blockBlobClient);
        when(batchConfig.getTransaction()).thenReturn(1);

    }

    /**
     * Verifies that a valid transaction file from test resources is processed correctly.
     *
     * <p>This test simulates the Azure Blob stream using a real file (`inputfile.txt`) from
     * {@code src/test/resources/data}. It ensures that the asynchronous file processing logic
     * executes without exceptions and that expected blob interactions occur.
     *
     * @throws Exception if resource loading or mock setup fails
     */
    @Test
    void testProcessAndSaveFile_positiveFlow_usingRealResourceFile() throws Exception {

        URL resourceUrl = getClass().getClassLoader().getResource("data/inputfile.txt");
        assertNotNull(resourceUrl, "Test input file must exist in resources");
        Path path = Paths.get(resourceUrl.toURI());
        String fileName = path.getFileName().toString();// "inputfile.txt"
        InputStream realInputStream = Files.newInputStream(path);

        when(blobInputStream.read(any(byte[].class), anyInt(), anyInt()))
                .thenAnswer(invocation -> realInputStream.read(
                        invocation.getArgument(0),
                        invocation.getArgument(1),
                        invocation.getArgument(2)));
        when(blobInputStream.read()).thenAnswer(invocation -> realInputStream.read());
        doAnswer(invocation -> {
            realInputStream.close();
            return null;
        }).when(blobInputStream).close();

        when(blobContainerClient.getBlobClient("inputfile.txt")).thenReturn(blobClient);
        when(blobClient.openInputStream()).thenReturn(blobInputStream);
        when(enrichedBlobContainerClient.getBlobClient(any()))
                .thenReturn(blobClient);

        when(blobClient.getBlockBlobClient()).thenReturn(blockBlobClient);
        when(blobClient.exists()).thenReturn(true);
        when(blockBlobClient.commitBlockList(anyList())).thenReturn(blockBlobItem);
        doNothing().when(blockBlobClient).stageBlock(anyString(), any(InputStream.class), anyLong());
        when(batchConfig.getTransaction()).thenReturn(1);
        when(objectMapper.writeValueAsString(any())).thenReturn("{\"txn\":\"ok\"}");

        FieldMapping fieldMappingTxnNumber = new FieldMapping();
        fieldMappingTxnNumber.setFieldName("transaction_number");
        fieldMappingTxnNumber.setRecordNumber(1);
        fieldMappingTxnNumber.setRecordType("transaction");
        fieldMappingTxnNumber.setStart(2);
        fieldMappingTxnNumber.setLength(7);

        FieldMapping fieldMappingPan = new FieldMapping();
        fieldMappingPan.setFieldName("pan");
        fieldMappingPan.setRecordNumber(1);
        fieldMappingPan.setRecordType("transaction");
        fieldMappingPan.setStart(14);
        fieldMappingPan.setLength(19);

        when(fieldMappingConfig.getFieldMappings()).thenReturn(List.of(fieldMappingTxnNumber, fieldMappingPan));

        assertDoesNotThrow(() -> fileReaderService.processAndSaveFile(fileName));
    }

    @Test
    void testProcessAndSaveFile_shouldThrowFileNotFoundException_whenBlobDoesNotExist() {
        // Given
        String fileName = "missingfile.txt";

        // When the blob client is requested for the given file
        when(blobContainerClient.getBlobClient(fileName)).thenReturn(blobClient);
        when(blobClient.exists()).thenReturn(false); // Simulate file missing

        // Then
        FileNotFoundException exception = assertThrows(FileNotFoundException.class,
                () -> fileReaderService.processAndSaveFile(fileName));

        assertTrue(exception.getMessage().contains(SOURCE_FILE_NOT_FOUND));
        assertTrue(exception.getMessage().contains(fileName));
    }
}

